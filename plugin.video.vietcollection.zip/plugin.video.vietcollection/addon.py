# -*- coding: utf-8 -*-

# https://docs.python.org/2.7/
import os
import sys
import urllib
import urlparse
# http://mirrors.kodi.tv/docs/python-docs/
import xbmcaddon
import xbmcgui
import xbmcplugin
# http://docs.python-requests.org/en/latest/
import requests
# http://www.crummy.com/software/BeautifulSoup/bs4/doc/
# from bs4 import BeautifulSoup
import re
from random import randint


addon= xbmcaddon.Addon()
addonname= addon.getAddonInfo('name')
SERVERNM= "http://video.tonghop.de/"
#SERVERNM= "http://127.0.0.1/flvlistplayer/"
PLAYLISTURL= SERVERNM + "playlists.php"
THUMBDIR= SERVERNM + "thumbs/"
CLIPDIR= SERVERNM + "selection/"


def show_message(txt):
    xbmcgui.Dialog().ok(addonname, txt)




def get_url_contents(url):
    # download the source
    txt= requests.get(url).text
    txt= txt.replace("\r","")
    return txt
	





def takeRandomThumb(txt, isum):
    lineA= re.findall("\n"+str(isum)+".\t.*?\n", txt)
    if len(lineA)==0:
       return ""
    
    lnx=  randint(0,len(lineA)-1)
    fieldA= lineA[lnx].split("\t")
    thumbx= fieldA[1]+'.jpg'
    #resstr= "".join(lineA)
    #show_message(resstr)
    return thumbx

	
def takeRandomThumb2(catxx):
    if catxx=='11':   #moi co newest
       txt= get_url_contents(SERVERNM + "newest.php")
       txtA= txt.split("\t")
       return txtA[0]+'.jpg'  #thumbnail newest
	   
    txt= get_url_contents(PLAYLISTURL)
    txtA= txt.split("=*=\n")
    
    lineA= re.findall("\n"+str(catxx)+"\t.*?\n", txtA[3])
    
    if len(lineA)==0:
       return ""
    
    if len(lineA)==1:
        lnx=0
    else:
        lnx=  randint(0,len(lineA)-1)
    
    fieldA= lineA[lnx].split("\t")
    thumbx= fieldA[1]+'.jpg'
    #if catxx=='14':
    #   show_message(catxx+'==='+thumbx)
    return thumbx
	

	
#1-- 1.Menu , Trang Nhat, Ca Nhac VN, Phim VN,....	
def show_mainmnu():
    txt= get_url_contents(PLAYLISTURL)
    txtA= txt.split("=*=\n")
    #show_message(txtA[1])
    cateA= txtA[2].split("\n")
    catlist=[]   
    idxnr=0
    thmb=-1
    for catex in cateA[0:]:
       idxnr= idxnr+1
       thmb= thmb+1
       catexA= catex.split("\t")
       submnu= 'TAB'.join(catexA[1:])
       submnu= submnu.replace(" ", "+")
       urlx = sys.argv[0] + '?mode=smnu&slist=' + str(idxnr) + 'TAB' + submnu
       thmbnail= takeRandomThumb(txtA[3], idxnr)  #take any Thumbnails depend on 
       if catexA[0]=='':
          continue
       li = xbmcgui.ListItem(label=catexA[0], thumbnailImage=THUMBDIR+thmbnail)
       catlist.append((urlx, li, True))   #link zu directory=True 
       #show_message(catexA[0]+"==="+urlx)
    xbmcplugin.setContent(addon_handle, 'movies')
    xbmcplugin.addDirectoryItems(addon_handle, catlist, len(catlist))
    xbmcplugin.endOfDirectory(addon_handle)

	
	
#2--- 2.Menu: moi co, thoi su, chuyen la,...
def show_sublist(slist):
    slistA= slist.split("TAB")
    catx1= slistA[0]
    idxnr=0
    subcatlist=[]
    for slistx in slistA[1:]:
        idxnr= idxnr+1
        catxx= catx1 + str(idxnr)
        urlx = sys.argv[0] + '?mode=smnu1&cat=' + catxx
        thmbnail= takeRandomThumb2(catxx)  #take any Thumbnails depend on 
        #show_message(slistx+thmbnail)
        if slistx=='':
           continue
        li = xbmcgui.ListItem(label=slistx,thumbnailImage=THUMBDIR+thmbnail ) 
        #li = xbmcgui.ListItem(label=slistx,thumbnailImage=THUMBDIR+'ttquanamxaycau.jpg')
        subcatlist.append((urlx, li, True))  #link zu directory=True
        #show_message(urlx)
    xbmcplugin.setContent(addon_handle, 'movies')
    xbmcplugin.addDirectoryItems(addon_handle, subcatlist, len(subcatlist))
    xbmcplugin.endOfDirectory(addon_handle)



#3--- 3.Menu: Title of Serie 
def show_playlist(cat):
    if cat=='11':
	   show_newestlist()
	   return
	
    txt= get_url_contents(PLAYLISTURL)
    #txt= txt.replace("\r","")
    txtA= txt.split("=*=\n")
    serieA= txtA[3].split("\n")
    serielist=[]
    for serie in serieA:
        attxA= serie.split("\t")
        #serie= urllib.urlencode(serie)
        #serie= serie.replace("\t", "TAB")
        if attxA[0] == cat:
           urlx = sys.argv[0] + '?mode=serie&serie=' + attxA[1]
           li = xbmcgui.ListItem(label=attxA[2],thumbnailImage=THUMBDIR+attxA[1]+'.jpg')
           serielist.append((urlx, li, True))  #link zu directory=True
           #show_message(resstr)
    xbmcplugin.setContent(addon_handle, 'movies')
    xbmcplugin.addDirectoryItems(addon_handle, serielist, len(serielist))
    xbmcplugin.endOfDirectory(addon_handle)


	

#4--- 4.Title Moi Co
def show_newestlist():
    lnewest= SERVERNM + "newest.php"
    txt= get_url_contents(lnewest)
    #txt= txt.replace("\r","")
    serieA= txt.split("\n")
    serielist=[]
    for serie in serieA:
        attxA= serie.split("\t")
        attxA[1]= attxA[1].replace("<br>", "\n")
        urlx = sys.argv[0] + '?mode=serie&serie=' + attxA[0]
        li = xbmcgui.ListItem(label=attxA[1],thumbnailImage=THUMBDIR+attxA[0]+'.jpg')
        serielist.append((urlx, li, True))  #link zu directory=True
    xbmcplugin.setContent(addon_handle, 'movies')
    xbmcplugin.addDirectoryItems(addon_handle, serielist, len(serielist))
    xbmcplugin.endOfDirectory(addon_handle)
    



def get_clipthumbnail(clipid, srvr, serie):
    xmlurl=''
    if srvr==1:
       xmlurl= "http://www.youtube.com/oembed?format=xml&url=http%3A//youtube.com/watch%3Fv%3D" + clipid 
    elif srvr==2:
       xmlurl= "http://www.dailymotion.com/services/oembed?format=xml&url=http%3A%2F%2Fwww.dailymotion.com%2Fswf%2F" + clipid 

    if xmlurl=='':   #z.B. vimeo
       return  THUMBDIR + serie + '.jpg'
	   
    txt= get_url_contents(xmlurl)
    thmbA= re.findall("<thumbnail_url>(.*?)</thumbnail_url>", txt)
    if thmbA:
       thmb= thmbA[0]
       thmb= thmb.replace("<.*?>", "")
    else:
	   thmb= '' #THUMBDIR + serie + '.jpg'
    
    return thmb
	   
    
	
	
#THUMBDIR= SERVERNM + "thumbs/"
#CLIPDIR= SERVERNM + "selection/"
def show_serie(serie):
    #serie= "50nambaoquoc"  #"langevop3" 
    txt= get_url_contents(CLIPDIR + serie + '.php')
    clipA= txt.split("\n")
    if "\t" in clipA[1]:
       (slabel,tmp)= clipA[1].split("\t")
    else:
       slabel= clipA[1]

    #thumbx= THUMBDIR + serie + '.jpg'
        
    cliplist=[]
    idxnr=0
	
    for clipx in clipA[3:]:
        clipxA= clipx.split("\t")
        tmpA= clipxA[0].split("/")
        srvr=0
        if "www.youtube.com" in tmpA:
           srvr=1
        elif "www.dailymotion.com" in tmpA:
		   srvr=2
        if srvr==0:
		   continue
        idxnr= idxnr+1
        clipId= tmpA[len(tmpA)-1]
        thumbx= get_clipthumbnail(clipId, srvr, serie)
        if thumbx=='':
           continue
        
        urlx = sys.argv[0] + '?mode=play&srvr=' + str(srvr) + '&clipid=' + clipId
        li= xbmcgui.ListItem(label='[ ' + str(idxnr) +' ] ' + slabel, thumbnailImage=thumbx)
        li.setProperty('IsPlayable', 'true')
        cliplist.append((urlx, li, False))  #Play
    xbmcplugin.setContent(addon_handle, 'movies')
    xbmcplugin.addDirectoryItems(addon_handle, cliplist, len(cliplist))
    xbmcplugin.endOfDirectory(addon_handle)
    
	

"""
morgen test mit: -------------- -----------
    xbmcplugin.setContent(addon_handle, 'movies')
    li = xbmcgui.ListItem("OneFileName", iconImage='')
    #url= "http://www.vidsplay.com/vids/us_postal.mp4"
    #url="http://127.0.0.1/flugservice/daily/VIE-2017-0509-1400.mp3"
    url="plugin://plugin.video.youtube/play/?video_id=yNMXe953qNE"
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)
"""


### Play-Command ##########
def play_clip(clipid,srvr):
    #show_message(clipid)
    #url="http://127.0.0.1/flugservice/daily/VIE-2017-0509-1400.mp3"    # okay
    #url="http://www.vidsplay.com/vids/us_postal.mp4" # mp4 auch so okay
    #url="http://127.0.0.1/flvlistplayer/secondstreaming.strm"  # strm so okay
    if srvr=='1':
       url="plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid=" + clipid #kay
    else:
       url="plugin://plugin.video.dailymotion_com/?mode=playVideo&url=" + clipid #okay
    play_item = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
	









################################################################################
def main():
    args = urlparse.parse_qs(sys.argv[2][1:])
    mode = args.get('mode', None)
    
    # initial launch of add-on
    if mode is None:
        show_mainmnu()
    elif mode[0] == 'smnu':
	    show_sublist(args['slist'][0])
    elif mode[0] == 'smnu1':
	    show_playlist(args['cat'][0])
    elif mode[0] == 'serie':
	    show_serie(args['serie'][0])		
    elif mode[0] == 'play':
        play_clip(args['clipid'][0], args['srvr'][0])		


    
if __name__ == '__main__':
    addon_handle = int(sys.argv[1])
    main()