import sys
import os
import urllib.request


def get_params():
  """
  Retrieves the current existing parameters from XBMC.
  """
  param = []
  paramstring = sys.argv[2]
  if len(paramstring) >= 2:
    params = sys.argv[2]
    cleanedparams = params.replace('?', '')
    if params[len(params) - 1] == '/':
      params = params[0:len(params) - 2]
    pairsofparams = cleanedparams.split('&')
    param = {}
    for i in range(len(pairsofparams)):
      splitparams = {}
      splitparams = pairsofparams[i].split('=')
      if (len(splitparams)) == 2:
        param[splitparams[0]] = splitparams[1]
  return param


"""
def get_content_url(url):     ### url= 'http://127.0.0.1/flvlistplayer/test12345.php'
   with urllib.request.urlopen(url) as response:
      cont = response.read() ###cont= b'Ng\xe1\xbb\x8dc \xc3\x81nh'
   return cont.decode('utf-8') ####decodestr= 'Ngọc Ánh'
 
#queryhash=  { 'mode':'smnu', 'slist':submnu }
#urlx = sys.argv[0] + '?' + urllib.urlencode(queryhash)
"""   
  
###########################################################